SELECT * FROM Online_Retail_Store.category;
UPDATE Online_Retail_Store.category
SET category_name='B-Series20'
WHERE category_id='1'